def mult_matrices (matriz1,matriz2):
    if isinstance (matriz1,list) and (matriz2,list) and len(matriz1)== len(matriz2[0]):
        return mult_aux(matriz1,matriz2,0,0,0,0,[],0)
    else:
        return "error"



def mult_aux (matriz1,matriz2,fila1,columna1,fila2,columna2,resultado,suma):
    if fila1 == len(matriz1):
        return resultado
    elif columna1 == len(matriz1[0]):
        return mult_aux(matriz1,matriz2,fila1,0,0,columna2+1,resultado+[suma], 0)
    elif columna2 == len(matriz2[0]):
       return mult_aux(matriz1,matriz2,fila1+1,0,0,0,resultado+[suma],0)
    elif fila2 == len(matriz2):
        return mult_aux(matriz1,matriz2,fila1,columna1,0,columna2+1,resultado+[suma],0)
    else:
       return mult_aux(matriz1,matriz2,fila1,columna1+1,fila2+1,columna2,resultado, suma + matriz1[fila1][columna1]* matriz2[fila2][columna2])









