/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculo;

public class Figura {
    public Figura(){
    }
    
    public int circulo(){
        int valor = 0;
        return valor;
    }

    public int circulo2(int valor){
        return valor*valor;
    }
    
    public int alto(){
        int valor = 0;
        return valor;
    }

    public int alto2(int valor1){
        return valor1;
    }
    
    public int ancho(){
        int valor2 = 0;
        return valor2;
    }

    public int ancho2(int valor2){
        return valor2;
    }
    

    public int area(int ancho, int alto){
        return ancho*alto;
    }

    double circulo(int valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    double alto(int valor1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    double ancho(int valor2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
