import pygame, sys
from pygame.locals import *
import time
import json
from json import dump, load
from time import sleep
from random import random


#lectura y escritura del archivo JSON
def json_file(path, data = None, delay = 0.1):
    while True:
        try:
            if data == None:
                with open(path, "r", encoding = "utf-8") as f:
                    return load(f)
            else:
                with open(path, "w", encoding = "utf-8") as f:
                    return dump(data, f)
        except:
            sleep(random()*delay)


#coordenadas x,y de la pantalla del juego
ancho=900
alto=630

#inicializacion de pygame
pygame.init()
pantalla = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('pyDeathRace')
clock = pygame.time.Clock()

#definicion de colores utilizados en el programa
blanco = (255,255,255)
rojo = (200,0,0)
rojo_claro = (255,0,0)
azul = (0,0,200)
azul_claro =(0,0,255)
verde =(0,150,0)
verde_claro = (0,200,0)
negro = (0,0,0)
tamaño = 48

FONDO = pygame.image.load("imágenes/pista1.png")

#definicion de imagenes de los autos
IC1_d = pygame.image.load("imágenes/carrito1.0.png")
IC1_r = pygame.image.load("imágenes/carrito1.1.png")
IC1_u = pygame.image.load("imágenes/carrito1.2.png")
IC1_l = pygame.image.load("imágenes/carrito1.3.png")

IC2_d = pygame.image.load("imágenes/carrito2.0.png")
IC2_r = pygame.image.load("imágenes/carrito2.1.png")
IC2_u = pygame.image.load("imágenes/carrito2.2.png")
IC2_l = pygame.image.load("imágenes/carrito2.3.png")

Ibot1_d = pygame.image.load("imágenes/bot1.0.png")
Ibot1_r = pygame.image.load("imágenes/bot1.1.png")
Ibot1_u = pygame.image.load("imágenes/bot1.2.png")
Ibot1_l = pygame.image.load("imágenes/bot1.3.png")

Ibot2_d = pygame.image.load("imágenes/bot2.0.png")
Ibot2_r = pygame.image.load("imágenes/bot2.1.png")
Ibot2_u = pygame.image.load("imágenes/bot2.2.png")
Ibot2_l = pygame.image.load("imágenes/bot2.3.png")

Ibot3_d = pygame.image.load("imágenes/bot3.0.png")
Ibot3_r = pygame.image.load("imágenes/bot3.1.png")
Ibot3_u = pygame.image.load("imágenes/bot3.2.png")
Ibot3_l = pygame.image.load("imágenes/bot3.3.png")

EXPLOSION = pygame.image.load("imágenes/explosión.png")

disparo1 = pygame.image.load("imágenes/granada1.png")
disparo2 = pygame.image.load("imágenes/granada2.png")

#coordenadas,imagen inicial y numero del carro
CARRO1 = [420,50,IC1_r,1]

CARRO2 = [420,80,IC2_r,2]


dummy1=[420,76,Ibot1_r,3]

dummy2=[420,76,Ibot2_r,4]

dummy3=[420,76,Ibot3_r,5]



#data = str({"spicy": 0, "maxy": 0, "rocket": 0, "rick": 0})


#json_str = json.dumps(data)
#print('datos en formato json', json_str)


#str_json = {"spicy": 0, "maxy": 0, "rocket": 0, "rick": 0}

#json_data = json.loads(str_json)

#print('objeto diccionario', json_data)

#with open('data.json', 'w') as file:
    #json.dump(data, file)

#with open('data.json', 'r') as file:
    #data = json.load(file)
    #print(data)


#funcion que define la aparicion de la imagen de la pista
def pista(posX,posY):
    pantalla.blit(FONDO,(posX,posY))

#funcion que define la aparicion de la imagen de la pista    
def carro(carro):
    pantalla.blit(carro[2],(carro[0],carro[1]))
    
def objetos_texto(texto, font):
    FondoTexto = font.render(texto, True, negro)
    return FondoTexto, FondoTexto.get_rect()

#mensaje que aparecerá al finalizar el juego, se le ingresa el texto deseado
def mensaje(texto):
    largo_texto =pygame.font.Font('freesansbold.ttf',100)
    pantalla_texto, TextRect = objetos_texto(texto, largo_texto)
    TextRect.center = ((ancho/2),(alto/2))
    pantalla.blit(pantalla_texto, TextRect)

    pygame.display.update()

    time.sleep(1000)

    loop_principal()
    
#funcion que define una vez que el auto colisiona, su entrada es un carro muestra
#en pantalla una explosion y acaba el juego
def explosion(carro):
    pantalla.blit(EXPLOSION,(carro[0],carro[1]))
    mensaje('Final del juego')

#definicion de los botones del menu y su funcion, se inserta en mensaje
#las coordenadas y su estado de accion
def botones(msg,x,y,w,h,inac,ac,action=None):

    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    print(click)
    
    if x+w > mouse[0] > x and y+h > mouse[1] > y:
        pygame.draw.rect(pantalla, ac,(x,y,w,h))
        if click[0] == 1 and action != None:
            if action == "play":
                loop_principal()
            elif action == "quit":
                pygame.quit()
                quit() 

            elif action == "set_nombre1" and msg == "spicy":
                jugador.set_nombre(msg)
            elif action == "set_nombre1" and msg == "max":
                jugador.set_nombre (msg)
            elif action == "set_nombre2" and msg == "rocket" :
                jugador.set_nombre(msg)
            elif action == "set_nombre2" and msg == "rick":
                jugador.set_nombre(msg)

            
    else:
        pygame.draw.rect(pantalla, inac,(x,y,w,h))

    menu_texto = pygame.font.Font("freesansbold.ttf", 20)
    pantalla_texto, TextRect = objetos_texto(msg, menu_texto)
    TextRect.center = ((x+(w/2)),(y+(h/2)))
    pantalla.blit(pantalla_texto,TextRect)

#menu que aparece al inicio de la ejecucion del programa, contiene los botones
#antes definidos
def juego_menu():

    menu= True
    while menu:
        for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    quit()

        pantalla.fill(blanco)

        largo_texto =pygame.font.Font('freesansbold.ttf',100)
        pantalla_texto, TextRect = objetos_texto("PyDeathRace", largo_texto)
        TextRect.center = ((ancho/2),(alto/2))
        pantalla.blit(pantalla_texto, TextRect)

        botones("Play",550,460,100,50,rojo,rojo_claro, "play")
        botones("quit game",550,510,100,50, verde, verde_claro,"quit")

        botones("spicy", 200, 460,100, 50, rojo, rojo_claro, "set_nombre1")
        botones("maxy", 200, 510,100, 50, rojo, rojo_claro, "set_nombre1")

        botones("rocket", 310, 460,100, 50, verde, verde_claro, "set_nombre2")
        botones("rick", 310, 510,100, 50, verde, verde_claro, "set_nombre2")

        

        
        mouse = pygame.mouse.get_pos()

            

        pygame.display.update()
        clock.tick(15)


#clase para brindar y obtener informacion utilizada en el JSON
class jugador (object):
    def __init__(self,nombre,puntaje,tiempo):
        self.nombre = nombre
        self.puntaje = puntaje
        self.tiempo = tiempo


    def get_nombre (self):
        return self.nombre

    def set_nombre (self, nombre):
        self.nombre = nombre

    def get_puntaje (self):
        return self.puntaje

    def set_puntaje (self, puntaje ):
        self.puntaje = puntaje

    def get_tiempo (self):
        return self.tiempo

    def set_tiempo (self, tiempo ):
        self.tiempo = tiempo



#movimiento y rotacion de los carros enemigos utilizando sus coordenadas
#respectivas y su velocidad 

def rotar_dummy3 (carro):
    cambio3_x = 0
    cambio3_y = 0


    if carro[0] == 804 and carro[1] <= 530:
        if carro[3] == 5:
            carro[2]=Ibot3_d
            cambio3_y +=4
        

    if carro[0] >= 80 and carro[1] == 532:
        if carro[3] == 5:
            carro[2]=Ibot3_l
            cambio3_x -=4
        

    if carro[0] == 76 and carro[1] >= 80 :
        if carro[3] == 5:
            carro[2]=Ibot3_u
            cambio3_y -=4
        
        

    if carro[0] <= 800 and carro[1] == 76  :
        if carro[3] == 5:
            carro[2]=Ibot3_r
            cambio3_x +=4
        

    if carro[0] ==76 and carro[1] == 76  :
        if carro[3] == 5:
            carro[2]=Ibot3_r
            cambio3_x +=4
        

    dummy3[0]+=cambio3_x
    dummy3[1]+=cambio3_y


    pygame.display.update()

#movimiento y rotacion de los carros enemigos utilizando sus coordenadas
#respectivas y su velocidad
def rotar_dummy2 (carro):
    cambio2_x = 0
    cambio2_y = 0


    if carro[0] == 804 and carro[1] <= 530:
        if carro[3] == 4:
            carro[2]=Ibot2_d
            cambio2_y +=8
        

    if carro[0] >= 80 and carro[1] == 532:
        if carro[3] == 4:
            carro[2]=Ibot2_l
            cambio2_x -=8
        

    if carro[0] == 76 and carro[1] >= 80 :
        if carro[3] == 4:
            carro[2]=Ibot2_u
            cambio2_y -=8
        
        

    if carro[0] <= 800 and carro[1] == 76  :
        if carro[3] == 4:
            carro[2]=Ibot2_r
            cambio2_x +=8
        

    if carro[0] ==76 and carro[1] == 76  :
        if carro[3] == 4:
            carro[2]=Ibot2_r
            cambio2_x +=8
        

    dummy2[0]+=cambio2_x
    dummy2[1]+=cambio2_y


    pygame.display.update()

#movimiento y rotacion de los carros enemigos utilizando sus coordenadas
#respectivas y su velocidad
def rotar_dummy1 (carro):
    cambio1_x = 0
    cambio1_y = 0


    if carro[0] == 804 and carro[1] <= 530:
        if carro[3] == 3:
            carro[2]=Ibot1_d
            cambio1_y +=12
        

    if carro[0] >= 80 and carro[1] == 532:
        if carro[3] == 3:
            carro[2]=Ibot1_l
            cambio1_x -=8
        

    if carro[0] == 76 and carro[1] >= 80 :
        if carro[3] == 3:
            carro[2]=Ibot1_u
            cambio1_y -=8
        
        

    if carro[0] <= 800 and carro[1] == 76  :
        if carro[3] == 3:
            carro[2]=Ibot1_r
            cambio1_x +=12
        

    if carro[0] ==76 and carro[1] == 76  :
        if carro[3] == 3:
            carro[2]=Ibot1_r
            cambio1_x +=8
        

    dummy1[0]+=cambio1_x
    dummy1[1]+=cambio1_y


    pygame.display.update()

def puntuacion(indice):
    indice = 0
    if carro[0] == 420 and carro[1] == 50 or carro[0] == 420 and carro[1] == 80:
        indice += 1


#funcion que define la rotacion de los autos controlados por el teclado
#por medio de las coordenadas de cada carro y sus limites
def rotar(carro):
    if carro[0] > 750 and carro[1] > 70 and carro[1] < 400:
        if carro[3] == 1:
            carro[2]=IC1_d
        else:
            carro[2]=IC2_d

    if carro[0] < 790 and carro[0] > 100  and carro[1] > 400:
        if carro[3] == 1:
            carro[2]=IC1_l
        else:
            carro[2]=IC2_l

    if carro[0] < 100 and carro[1] < 500 and carro[1] > 120 :
        if carro[3] == 1:
            carro[2]=IC1_u
        else:
            carro[2]=IC2_u

    if carro[0] > 50 and carro[1] < 100  and carro[0]  < 800  :
        if carro[3] == 1:
            carro[2]=IC1_r
        else:
            carro[2]=IC2_r



def pantalla_final(pantalla,fuente,tamaño,x,y,texto,color):
    fuente = pygame.font.Font ('font.ttf',10)
    texto = font.render("",1, negro)
    pantalla.blit("",(ancho//2,alto//2))



#funcion del loop principal en el cual aparecen los carros y sus eventos
def loop_principal():
    posX=30
    posY=50

    x_rect = 130
    y_rect = 130
    w_rect = 640
    h_rect = 370

    x_cambia1 = 0
    y_cambia1 = 0

    x_cambia2 = 0
    y_cambia2 = 0

    jugador1 = jugador ("","","")
    jugador2 = jugador ("","","")

    salir = False


    while not salir:

        pantalla.fill(verde)
        pista(posX,posY)
        pygame.draw.rect(pantalla,(0,150,0),(x_rect,y_rect,w_rect,h_rect))
        fuente_cronometro = pygame.font.Font('freesansbold.ttf',25)
        tiempo = fuente_cronometro.render ("Time :", 0, negro)
        pantalla.blit (tiempo, (2,10))
        
        fuente_tiempo = pygame.font.Font('freesansbold.ttf',25)
        segundos = pygame.time.get_ticks() //1000
        cronometro = str (segundos)
        contador = fuente_tiempo.render (cronometro, 0, negro)
        pantalla.blit (contador, (70,10))

        
        fuente_puntu = pygame.font.Font('freesansbold.ttf',25)
        puntos = fuente_cronometro.render ("Highscore:", 0, negro)
        pantalla.blit (puntos, (700,10))

        


        carro(CARRO1)
        carro(CARRO2)
        carro(dummy1)
        carro(dummy2)
        carro(dummy3)
       
        #eventos ejecutados por el teclado para controlar la direccion de los carros
        for event in pygame.event.get():
                if event.type == QUIT:
                    salir = True

                if event.type == pygame.KEYDOWN:
                    if event.key == K_LEFT:
                        x_cambia1 = -5
                        rotar(CARRO1)
                    elif event.key == K_RIGHT:
                        x_cambia1 = 5
                        rotar(CARRO1)
                    if event.key == K_UP:
                        y_cambia1 = -5
                        rotar(CARRO1)
                    elif event.key == K_DOWN:
                        y_cambia1 = 5
                        rotar(CARRO1)
                        

                    if event.key == K_a:
                        x_cambia2 = -5
                        rotar(CARRO2)
                    elif event.key == K_d:
                        x_cambia2 = 5
                        rotar(CARRO2)
                    if event.key == K_w:
                        y_cambia2 = -5
                        rotar(CARRO2)
                    elif event.key == K_s:
                        y_cambia2 = 5
                        rotar(CARRO2)

            
                        
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        x_cambia1 = 0
                        rotar(CARRO1)

                        
                    if event.key == pygame.K_RIGHT:
                        x_cambia1 = 0
                        rotar(CARRO1)

                        
                    if event.key == pygame.K_UP:
                        y_cambia1 = 0
                        rotar(CARRO1)

                    if event.key == pygame.K_DOWN:
                        y_cambia1 = 0
                        rotar(CARRO1)

                    if event.key == pygame.K_a:
                        y_cambia2 = 0
                        rotar(CARRO2)
                    if event.key == pygame.K_d:
                        x_cambia2 = 0
                        rotar(CARRO2)
                    if event.key == pygame.K_w:
                        y_cambia2 = 0
                        rotar(CARRO2)
                    if event.key == pygame.K_s:
                        y_cambia2 = 0
                        rotar(CARRO2)

                    

                    

                    
        CARRO1[0] += x_cambia1
        CARRO1[1] += y_cambia1


        CARRO2[0] += x_cambia2
        CARRO2[1] += y_cambia2

            
        #límites de los carros, en este punto se manda a llamar
        #una funcion que simula una explosion y acaba el juego
        if CARRO1[0] > 830 or CARRO1[0] < 20:
            explosion(CARRO1)
            
        if CARRO1[1] > 570 or CARRO1[1] < 30:
            explosion(CARRO1)

        if CARRO1[0] > 100 and CARRO1[1] > 100 and CARRO1[0] < 770 and CARRO1[1] < 490 :
            explosion(CARRO1)

        if CARRO2[0] > 830 or CARRO2[0] < 20:
            explosion(CARRO2)
        if CARRO2[1] > 570 or CARRO2[1] < 30:
            explosion(CARRO2)
        if CARRO2[0] > 100 and CARRO2[1] > 100 and CARRO2[0] < 770 and CARRO2[1] < 490 :
            explosion(CARRO2)



        rotar_dummy3(dummy3)
        rotar_dummy2(dummy2)
        rotar_dummy1(dummy1)


        print(pygame.mouse.get_pos())  
        pygame.display.update()
        clock.tick(40)

    jugador1.set_nombre(msg)
    jugador1.set_tiempo(cronometro)
    jugador1.set_puntaje(punt)

    jugador2.set_nombre(msg)
    jugador2.set_tiempo(cronometro)
    jugador2.set_puntaje(punt)






juego_menu()
loop_principal()
pygame.quit()
quit()

    
