import pygame, sys
from pygame.locals import *
import time

ancho=900
alto=630


pygame.init()
superf = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('pyDeathRace')
clock = pygame.time.Clock()

#definicion de colores utilizados en el programa
blanco = (255,255,255)
rojo = (200,0,0)
rojo_claro = (255,0,0)
azul = (0,0,200)
azul_claro =(0,0,255)
verde =(0,150,0)
verde_claro = (0,200,0)
negro = (0,0,0)
tamaño = 48

FONDO = pygame.image.load("imágenes/pista1.png")

#definicion de imagenes de los autos
IC1_d = pygame.image.load("imágenes/carrito1.0.png")
IC1_r = pygame.image.load("imágenes/carrito1.1.png")
IC1_u = pygame.image.load("imágenes/carrito1.2.png")
IC1_l = pygame.image.load("imágenes/carrito1.3.png")

IC2_d = pygame.image.load("imágenes/carrito2.0.png")
IC2_r = pygame.image.load("imágenes/carrito2.1.png")
IC2_u = pygame.image.load("imágenes/carrito2.2.png")
IC2_l = pygame.image.load("imágenes/carrito2.3.png")

Ibot1_d = pygame.image.load("imágenes/bot1.0.png")
Ibot1_r = pygame.image.load("imágenes/bot1.1.png")
Ibot1_u = pygame.image.load("imágenes/bot1.2.png")
Ibot1_l = pygame.image.load("imágenes/bot1.3.png")

Ibot2_d = pygame.image.load("imágenes/bot2.0.png")
Ibot2_r = pygame.image.load("imágenes/bot2.1.png")
Ibot2_u = pygame.image.load("imágenes/bot2.2.png")
Ibot2_l = pygame.image.load("imágenes/bot2.3.png")

Ibot3_d = pygame.image.load("imágenes/bot3.0.png")
Ibot3_r = pygame.image.load("imágenes/bot3.1.png")
Ibot3_u = pygame.image.load("imágenes/bot3.2.png")
Ibot3_l = pygame.image.load("imágenes/bot3.3.png")

EXPLOSION = pygame.image.load("imágenes/explosión.png")

CARRO1 = [420,50,IC1_r,1]

CARRO2 = [420,80,IC2_r,2]

#funcion que define la aparicion de la imagen de la pista
def pista(posX,posY):
    superf.blit(FONDO,(posX,posY))

#funcion que define la aparicion de la imagen de la pista    
def carro(carro):
    superf.blit(carro[2],(carro[0],carro[1]))
    
def objetos_texto(texto, font):
    FondoTexto = font.render(texto, True, negro)
    return FondoTexto, FondoTexto.get_rect()

#mensaje que aparecerá al finalizar el juego
def mensaje(texto):
    largo_texto =pygame.font.Font('freesansbold.ttf',100)
    superf_texto, TextRect = objetos_texto(texto, largo_texto)
    TextRect.center = ((ancho/2),(alto/2))
    superf.blit(superf_texto, TextRect)

    pygame.display.update()

    time.sleep(1000)

    loop_principal()
    
#funcion que define una vez que el auto colisiona  
def explosion(carro):
    superf.blit(EXPLOSION,(carro[0],carro[1]))
    mensaje('Final del juego')

def botones(msg,x,y,w,h,inac,ac,action=None):

    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    print(click)
    
    if x+w > mouse[0] > x and y+h > mouse[1] > y:
        pygame.draw.rect(superf, ac,(x,y,w,h))
        if click[0] == 1 and action != None:
            if action == "play":
                loop_principal()
            elif action == "quit":
                pygame.quit()
                quit() 
            
    else:
        pygame.draw.rect(superf, inac,(x,y,w,h))

    menu_texto = pygame.font.Font("freesansbold.ttf", 20)
    superf_texto, TextRect = objetos_texto(msg, menu_texto)
    TextRect.center = ((x+(w/2)),(y+(h/2)))
    superf.blit(superf_texto,TextRect)

#menu que aparece al inicio de la ejecucion del programa
def juego_menu():

    menu= True
    while menu:
        for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    quit()

        superf.fill(blanco)

        largo_texto =pygame.font.Font('freesansbold.ttf',100)
        superf_texto, TextRect = objetos_texto("PyDeathRace", largo_texto)
        TextRect.center = ((ancho/2),(alto/2))
        superf.blit(superf_texto, TextRect)

        botones("Play",200,400,100,50,rojo,rojo_claro, "play")
        botones("quit game",550,400,100,50, verde, verde_claro,"quit")
        

        
        mouse = pygame.mouse.get_pos()

            

        pygame.display.update()
        clock.tick(15)

#funcion que define la rotacion de los autos        
def rotar(carro):
    if carro[0] > 750 and carro[1] > 70 and carro[1] < 400:
        if carro[3] == 1:
            carro[2]=IC1_d
        else:
            carro[2]=IC2_d

    if carro[0] < 790 and carro[0] > 100  and carro[1] > 400:
        if carro[3] == 1:
            carro[2]=IC1_l
        else:
            carro[2]=IC2_l

    if carro[0] < 100 and carro[1] < 500 and carro[1] > 120 :
        if carro[3] == 1:
            carro[2]=IC1_u
        else:
            carro[2]=IC2_u

    if carro[0] > 50 and carro[1] < 100  and carro[0]  < 800  :
        if carro[3] == 1:
            carro[2]=IC1_r
        else:
            carro[2]=IC2_r

#fincion del loop principal en el cual aparecen los carros y sus eventos
def loop_principal():
    posX=30
    posY=50
    CARRO1[0]=420
    CARRO1[1]=50
    CARRO2[0]=420
    CARRO2[1]=80
    

    x_rect = 130
    y_rect = 130
    w_rect = 640
    h_rect = 370

    x_cambia1 = 0
    y_cambia1 = 0

    x_cambia2 = 0
    y_cambia2 = 0

    salir = False

    while not salir:

        superf.fill(verde)
        pista(posX,posY)
        pygame.draw.rect(superf,(0,150,0),(x_rect,y_rect,w_rect,h_rect))
        carro(CARRO1)
        carro(CARRO2)
        
        for event in pygame.event.get():
                if event.type == QUIT:
                    salir = True

                if event.type == pygame.KEYDOWN:
                    if event.key == K_LEFT:
                        x_cambia1 = -5
                        rotar(CARRO1)
                    elif event.key == K_RIGHT:
                        x_cambia1 = 5
                        rotar(CARRO1)
                    if event.key == K_UP:
                        y_cambia1 = -5
                        rotar(CARRO1)
                    elif event.key == K_DOWN:
                        y_cambia1 = 5
                        rotar(CARRO1)
                        

                    if event.key == K_a:
                        x_cambia2 = -5
                        rotar(CARRO2)
                    elif event.key == K_d:
                        x_cambia2 = 5
                        rotar(CARRO2)
                    if event.key == K_w:
                        y_cambia2 = -5
                        rotar(CARRO2)
                    elif event.key == K_s:
                        y_cambia2 = 5
                        rotar(CARRO2)

                    
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        x_cambia1 = 0
                        rotar(CARRO1)

                        
                    if event.key == pygame.K_RIGHT:
                        x_cambia1 = 0
                        rotar(CARRO1)

                        
                    if event.key == pygame.K_UP:
                        y_cambia1 = 0
                        rotar(CARRO1)

                        
                    if event.key == pygame.K_DOWN:
                        y_cambia1 = 0
                        rotar(CARRO1)

                    if event.key == pygame.K_a:
                        y_cambia2 = 0
                        rotar(CARRO2)
                    if event.key == pygame.K_d:
                        x_cambia2 = 0
                        rotar(CARRO2)
                    if event.key == pygame.K_w:
                        y_cambia2 = 0
                        rotar(CARRO2)
                    if event.key == pygame.K_s:
                        y_cambia2 = 0
                        rotar(CARRO2)
                    
        CARRO1[0] += x_cambia1
        CARRO1[1] += y_cambia1


        CARRO2[0] += x_cambia2
        CARRO2[1] += y_cambia2

            
        #límites
        if CARRO1[0] > 830 or CARRO1[0] < 20:
            explosion(CARRO1)
            
        if CARRO1[1] > 570 or CARRO1[1] < 30:
            explosion(CARRO1)

        if CARRO1[0] > 100 and CARRO1[1] > 100 and CARRO1[0] < 770 and CARRO1[1] < 490 :
            explosion(CARRO1)

        if CARRO2[0] > 830 or CARRO2[0] < 20:
            explosion(CARRO2)
        if CARRO2[1] > 570 or CARRO2[1] < 30:
            explosion(CARRO2)
        if CARRO2[0] > 100 and CARRO2[1] > 100 and CARRO2[0] < 770 and CARRO2[1] < 490 :
            explosion(CARRO2)

                       
        print(pygame.mouse.get_pos())  
        pygame.display.update()
        clock.tick(40)
juego_menu()
loop_principal()
pygame.quit()
quit()

    
